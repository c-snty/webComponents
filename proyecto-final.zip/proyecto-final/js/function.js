document.getElementById("agregar_contact").addEventListener("click", (e) => {
   e.preventDefault();
   let datos = {}
   let data = new FormData(document.getElementById('form-contacto'));

   const inputs = document.querySelectorAll("input");

   Array.from(inputs).forEach(elem => {
       datos[elem.name] = elem.value;
       console.log(datos[elem.name]);

   })

   fetch('http://localhost:8080/api/contactos', {
           method: 'POST',
           headers: {
               'Content-Type': 'application/json',
           },
           body: JSON.stringify(datos)
       })
       .then(function (data) {
           console.log('Request success: ', datos);
       })
       .catch(function (error) {
           console.log('Request failure: ', error);
       });
});
