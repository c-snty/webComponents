var div_contactos = document.querySelector("#contactos");
var td_contacto = document.querySelector("#tbody");

var contactoss = [];

	getContactos()
	.then(data => data.json())
		.then(contactos => {
			listadoContactos(contactos)
			
	})
		.catch(error =>{
			console.log(error);
		});

function getContactos(){
	return fetch('http://localhost:8080/api/contactos');
}

function listadoContactos(contactos){

	contactos.map((contacto, i) =>{
				let td_nombre = document.createElement('tr');
				let td_tel =	document.createElement('tr');

				contactos.map((contacto, i) =>{

					let tr_nombre = document.createElement('td');
					let tr_tel = document.createElement('td');
					tr_nombre.innerHTML = `${contacto.nombre_contacto}`;
					tr_tel.innerHTML = `${contacto.telefono_p}`;
					td_nombre.appendChild(tr_nombre);
					td_tel.appendChild(tr_tel);
				
				})
				

				

td_contacto.appendChild(td_nombre);
td_contacto.appendChild(td_tel);
			});
}
	// 
